<?php
abstract class UserAbstract
{
    abstract protected function showInfo();
}