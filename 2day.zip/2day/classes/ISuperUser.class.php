<?php
interface ISuperUser
{
    function getInfo();
}
